BASE_URL = "https://api.4projects.com/"
MAX_API_CALL_TRIES = 3
VIEWPOINT_APPLICATION_ID = ""
